// Initialize Video.js Players
let player;
let adminPreviewPlayer = null;
const DEFAULT_STREAM = "https://your-domain.com/hls/hindi/master.m3u8";

// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyDzIy4x_0rJVQK9olMmSzNmsqpa1nkM8ec",
  authDomain: "ndir-2176f.firebaseapp.com",
  databaseURL: "https://ndir-2176f-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "ndir-2176f",
  storageBucket: "ndir-2176f.firebasestorage.app",
  messagingSenderId: "660950118486",
  appId: "1:660950118486:web:61120b3590be2577254bf7",
  measurementId: "G-FQ1HPET77R"
};

// Initialize Firebase SDK
firebase.initializeApp(firebaseConfig);
const firebaseDb = firebase.database();

// Socket.io Fallback Client
const socket = typeof io !== 'undefined' ? io() : null;

// State
let adminToken = sessionStorage.getItem("rounderAdminToken") || null;
let adminPasswordCache = sessionStorage.getItem("rounderAdminPassword") || null;
let currentStreamData = null;

document.addEventListener("DOMContentLoaded", () => {
  player = videojs('live-player');

  // Start digital live timer clock
  startLiveTimer();

  // Seed default stream if database node is empty
  firebaseDb.ref('liveStream').once('value', (snapshot) => {
    if (!snapshot.exists() || snapshot.val().streamUrl.includes("sintel.smil")) {
      firebaseDb.ref('liveStream').set({
        streamUrl: DEFAULT_STREAM,
        title: "Hindi Master Live Stream",
        status: "LIVE",
        updatedAt: new Date().toISOString()
      });
    }
  });

  // Listen for Real-Time Stream Updates from Firebase Database
  firebaseDb.ref('liveStream').on('value', (snapshot) => {
    const data = snapshot.val();
    if (data && data.streamUrl) {
      if (currentStreamData && currentStreamData.streamUrl !== data.streamUrl) {
        showToast("🔥 Firebase Real-Time Sync: Broadcast Source Switched!");
      }
      currentStreamData = data;
      loadVideoSource(player, data.streamUrl);
      if (data.title) {
        document.getElementById('streamTitleDisplay').innerText = data.title;
      }
      if (document.getElementById('streamUrlInput')) {
        document.getElementById('streamUrlInput').value = data.streamUrl;
      }
      if (document.getElementById('streamTitleInput')) {
        document.getElementById('streamTitleInput').value = data.title;
      }
    }
  });

  // Track Live Connected Viewers Count in Firebase
  const presenceRef = firebaseDb.ref('liveViewers');
  const myPresence = presenceRef.push();
  firebaseDb.ref('.info/connected').on('value', (snap) => {
    if (snap.val() === true) {
      myPresence.onDisconnect().remove();
      myPresence.set(true);
    }
  });

  presenceRef.on('value', (snap) => {
    const count = snap.numChildren() || 1;
    const viewerElem = document.getElementById('viewerCountBadge');
    if (viewerElem) {
      viewerElem.innerHTML = `<span class="w-2 h-2 rounded-full bg-emerald-400 animate-live-dot mr-1.5"></span> ${count} Live Viewers`;
    }
  });

  // Handle modal enter key
  const passwordInput = document.getElementById("adminPasswordInput");
  if (passwordInput) {
    passwordInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") verifyAdminPassword();
    });
  }
});

// Helper to determine MIME type from video link
function getVideoType(url) {
  const cleanUrl = url.toLowerCase().split('?')[0];
  if (cleanUrl.endsWith(".mp4") || url.includes("sample/BigBuckBunny") || url.includes("ForBiggerBlazes")) {
    return "video/mp4";
  }
  if (cleanUrl.endsWith(".webm")) return "video/webm";
  if (cleanUrl.endsWith(".ogg") || cleanUrl.endsWith(".ogv")) return "video/ogg";
  return "application/x-mpegURL"; // HLS .m3u8 default
}

// Video Source Loader supporting HLS & MP4 with Error Handling
function loadVideoSource(targetPlayer, url) {
  if (!targetPlayer || !url) return;

  const type = getVideoType(url);

  // Reset error state
  targetPlayer.error(null);

  targetPlayer.src({
    src: url,
    type: type
  });

  targetPlayer.off('error');
  targetPlayer.on('error', () => {
    const err = targetPlayer.error();
    console.warn("Stream playback failed:", err);
    if (url.includes("your-domain.com")) {
      showToast("⚠️ 'your-domain.com' ek demo naam hai! Asli domain URL daalein.");
    } else {
      showToast("❌ Stream chal nahi raha! Check karein ki server live hai ya CORS allowed hai.");
    }
  });

  targetPlayer.ready(() => {
    targetPlayer.play().catch(err => {
      console.log("Autoplay prevented by browser policy:", err);
    });
  });
}

// Admin Preview Video Box Trigger
function previewAdminVideo() {
  const url = document.getElementById("streamUrlInput").value.trim();
  if (!url) {
    showToast("⚠️ Kripya pehle video link paste karein!");
    return;
  }

  const previewBox = document.getElementById("adminPreviewContainer");
  previewBox.classList.remove("hidden");
  previewBox.classList.add("flex");

  if (!adminPreviewPlayer) {
    adminPreviewPlayer = videojs('admin-preview-player');
  }

  loadVideoSource(adminPreviewPlayer, url);
  showToast("▶ Video Preview Loaded inside Admin Box!");
}

// Live Digital Clock Counter
function startLiveTimer() {
  const timerElement = document.getElementById("liveTimer");
  if (!timerElement) return;

  setInterval(() => {
    const now = new Date();
    const hrs = String(now.getHours()).padStart(2, '0');
    const mins = String(now.getMinutes()).padStart(2, '0');
    const secs = String(now.getSeconds()).padStart(2, '0');
    timerElement.innerText = `${hrs}:${mins}:${secs}`;
  }, 1000);
}

// View Switching & Protection Flow
function handleAdminButtonClick() {
  if (adminToken && adminPasswordCache) {
    switchView('admin');
  } else {
    openPasswordModal();
  }
}

function openPasswordModal() {
  const modal = document.getElementById("passwordModal");
  const input = document.getElementById("adminPasswordInput");
  const errorMsg = document.getElementById("modalErrorMsg");

  if (errorMsg) errorMsg.classList.add("hidden");
  modal.classList.remove("hidden");
  modal.classList.add("flex");
  setTimeout(() => input.focus(), 50);
}

function closePasswordModal() {
  const modal = document.getElementById("passwordModal");
  const input = document.getElementById("adminPasswordInput");
  modal.classList.add("hidden");
  modal.classList.remove("flex");
  input.value = "";
}

// Verify Password API
async function verifyAdminPassword() {
  const passwordInput = document.getElementById("adminPasswordInput");
  const errorMsg = document.getElementById("modalErrorMsg");
  const password = passwordInput.value.trim();

  if (!password) return;

  try {
    const response = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password })
    });
    
    const result = await response.json();

    if (result.success) {
      adminToken = result.token;
      adminPasswordCache = password;
      sessionStorage.setItem("rounderAdminToken", adminToken);
      sessionStorage.setItem("rounderAdminPassword", password);

      closePasswordModal();
      switchView('admin');
      showToast("🔓 Access Granted! Welcome to Stream Control.");
    } else {
      errorMsg.innerText = result.message || "Invalid password!";
      errorMsg.classList.remove("hidden");
      passwordInput.classList.add("border-red-500");
      setTimeout(() => passwordInput.classList.remove("border-red-500"), 1500);
    }
  } catch (err) {
    // Local static fallback login if backend server is not running
    if (password === "Nishad$100") {
      adminToken = "static_token_" + Date.now();
      adminPasswordCache = password;
      sessionStorage.setItem("rounderAdminToken", adminToken);
      sessionStorage.setItem("rounderAdminPassword", password);
      closePasswordModal();
      switchView('admin');
      showToast("🔓 Access Granted! (Firebase Mode)");
    } else {
      errorMsg.innerText = "Invalid password!";
      errorMsg.classList.remove("hidden");
    }
  }
}

function logoutAdmin() {
  adminToken = null;
  adminPasswordCache = null;
  sessionStorage.removeItem("rounderAdminToken");
  sessionStorage.removeItem("rounderAdminPassword");
  if (adminPreviewPlayer) {
    adminPreviewPlayer.pause();
  }
  document.getElementById("adminPreviewContainer").classList.add("hidden");
  document.getElementById("adminPreviewContainer").classList.remove("flex");
  switchView('user');
  showToast("🔒 Admin Logged Out Successfully");
}

// Switch View Tab (user <-> admin)
function switchView(view) {
  const userPage = document.getElementById("userPage");
  const adminPanel = document.getElementById("adminPanel");
  const viewUserBtn = document.getElementById("viewUserBtn");
  const viewAdminBtn = document.getElementById("viewAdminBtn");

  if (view === 'admin') {
    userPage.classList.add("hidden");
    adminPanel.classList.remove("hidden");
    viewAdminBtn.classList.add("active", "text-blue-400");
    viewAdminBtn.classList.remove("text-gray-400");
    viewUserBtn.classList.remove("active", "text-blue-400");
    viewUserBtn.classList.add("text-gray-400");
  } else {
    adminPanel.classList.add("hidden");
    userPage.classList.remove("hidden");
    viewUserBtn.classList.add("active", "text-blue-400");
    viewUserBtn.classList.remove("text-gray-400");
    viewAdminBtn.classList.remove("active", "text-blue-400");
    viewAdminBtn.classList.add("text-gray-400");
  }
}

// Update Stream Source via Firebase Realtime Database
function updateStreamSource() {
  const streamUrlInput = document.getElementById("streamUrlInput");
  const streamTitleInput = document.getElementById("streamTitleInput");
  const newUrl = streamUrlInput.value.trim();
  const newTitle = streamTitleInput ? streamTitleInput.value.trim() : "Live ROUNDER Stream";

  if (!newUrl) {
    showToast("⚠️ Please enter a valid video stream URL!");
    return;
  }

  const updatedPayload = {
    streamUrl: newUrl,
    title: newTitle,
    status: "LIVE",
    updatedAt: new Date().toISOString()
  };

  // Broadcast to Firebase Database
  firebaseDb.ref('liveStream').set(updatedPayload)
    .then(() => {
      showToast("🚀 Live Source Broadcasted Globally via Firebase!");
      setTimeout(() => switchView('user'), 1000);
    })
    .catch((err) => {
      console.error("Firebase broadcast error:", err);
      showToast("❌ Broadcast failed: Check Firebase security rules.");
    });

  // Also notify Express server if connected
  if (socket) {
    socket.emit('updateStream', { password: adminPasswordCache, streamUrl: newUrl, title: newTitle });
  }
}

// Quick Sample Templates
function setSampleUrl(url, title) {
  document.getElementById("streamUrlInput").value = url;
  if (title && document.getElementById("streamTitleInput")) {
    document.getElementById("streamTitleInput").value = title;
  }
  // Auto trigger preview if preview container is open
  const previewBox = document.getElementById("adminPreviewContainer");
  if (previewBox && !previewBox.classList.contains("hidden")) {
    previewAdminVideo();
  }
}

// Share Stream Link
function copyStreamLink() {
  navigator.clipboard.writeText(window.location.href);
  showToast("🔗 Stream link copied to clipboard!");
}

// Custom Toast Notification
function showToast(message) {
  const toast = document.getElementById("toast");
  if (!toast) return;

  toast.innerHTML = `<span class="flex items-center gap-2">${message}</span>`;
  toast.classList.remove("opacity-0", "translate-y-4", "pointer-events-none");
  toast.classList.add("opacity-100", "translate-y-0");

  setTimeout(() => {
    toast.classList.remove("opacity-100", "translate-y-0");
    toast.classList.add("opacity-0", "translate-y-4", "pointer-events-none");
  }, 3000);
}
