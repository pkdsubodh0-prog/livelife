// Register ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

// Initialize animations
function initAnimations() {
    // Navbar effect on scroll
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // Mobile Menu Toggle
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    const navItems = document.querySelectorAll('.nav-links a');

    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navLinks.classList.toggle('active');
    });

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navLinks.classList.remove('active');
        });
    });

    // Typewriter Effect
    const phrases = [
        "Digital Services Expert",
        "E-Governance Specialist",
        "Banking Operations Professional"
    ];
    let i = 0;
    let j = 0;
    let currentPhrase = [];
    let isDeleting = false;
    const textDisplay = document.getElementById('typewriter');

    function loop() {
        textDisplay.innerHTML = currentPhrase.join('');

        if (i < phrases.length) {
            if (!isDeleting && j <= phrases[i].length) {
                currentPhrase.push(phrases[i][j]);
                j++;
                textDisplay.innerHTML = currentPhrase.join('');
            }

            if (isDeleting && j <= phrases[i].length) {
                currentPhrase.pop(phrases[i][j]);
                j--;
                textDisplay.innerHTML = currentPhrase.join('');
            }

            if (j == phrases[i].length) {
                isDeleting = true;
                setTimeout(loop, 2000); // Wait before deleting
                return;
            }

            if (isDeleting && j === 0) {
                currentPhrase = [];
                isDeleting = false;
                i++;
                if (i === phrases.length) {
                    i = 0;
                }
            }
        }
        
        const speed = isDeleting ? 50 : 100;
        setTimeout(loop, speed);
    }
    
    // Start typewriter slightly after load
    setTimeout(loop, 1000);

    // Magnetic Button Effect
    const magneticElements = document.querySelectorAll('.magnetic');
    
    magneticElements.forEach((elem) => {
        elem.addEventListener('mousemove', (e) => {
            const rect = elem.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;
            
            gsap.to(elem, {
                x: x * 0.3,
                y: y * 0.3,
                duration: 0.4,
                ease: "power2.out"
            });
        });

        elem.addEventListener('mouseleave', () => {
            gsap.to(elem, {
                x: 0,
                y: 0,
                duration: 0.7,
                ease: "elastic.out(1, 0.3)"
            });
        });
    });

    // GSAP Scroll Animations
    
    // Hero Elements
    const tlHero = gsap.timeline();
    tlHero.from(".greeting", {y: 20, opacity: 0, duration: 0.6, delay: 0.2})
          .from(".glitch", {y: 20, opacity: 0, duration: 0.6}, "-=0.4")
          .from(".typewriter-container", {y: 20, opacity: 0, duration: 0.6}, "-=0.4")
          .from(".hero-desc", {y: 20, opacity: 0, duration: 0.6}, "-=0.4")
          .from(".hero-cta", {y: 20, opacity: 0, duration: 0.6}, "-=0.4")
          .from(".image-wrapper", {scale: 0.8, opacity: 0, duration: 1, ease: "back.out(1.7)"}, "-=0.8");

    // Sections Fade In & Slide Up
    const sections = gsap.utils.toArray('.section');
    sections.forEach((sec, i) => {
        if(sec.id !== 'hero') {
            gsap.from(sec, {
                scrollTrigger: {
                    trigger: sec,
                    start: "top 80%",
                    toggleActions: "play none none reverse"
                },
                y: 50,
                opacity: 0,
                duration: 0.8,
                ease: "power2.out"
            });
        }
    });

    // Education Cards Stagger
    gsap.from(".edu-card", {
        scrollTrigger: {
            trigger: "#education",
            start: "top 70%"
        },
        y: 50,
        opacity: 0,
        duration: 0.6,
        stagger: 0.15,
        ease: "power2.out"
    });

    // Progress Bars Animation
    const progressFills = document.querySelectorAll('.progress-fill');
    
    ScrollTrigger.create({
        trigger: "#skills",
        start: "top 70%",
        onEnter: () => {
            progressFills.forEach(fill => {
                const width = fill.getAttribute('data-width');
                gsap.to(fill, {
                    width: width,
                    duration: 1.5,
                    ease: "power2.out"
                });
            });
        }
    });

    // Active Nav Link Update on Scroll
    const navLinksList = document.querySelectorAll('.nav-links a');
    
    window.addEventListener('scroll', () => {
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            if (scrollY >= (sectionTop - 200)) {
                current = section.getAttribute('id');
            }
        });

        navLinksList.forEach(a => {
            a.classList.remove('active');
            if (a.getAttribute('href').includes(current)) {
                a.classList.add('active');
            }
        });
    });

    // Form submission is now handled by standard HTML POST request.
}

// Run animations after DOM loaded
document.addEventListener("DOMContentLoaded", initAnimations);
